package com.jsp.WeatherReportWebService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherReportWebServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherReportWebServiceApplication.class, args);
	}

}
