package com.jsp.WeatherReportWebService.SERVICE;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.WeatherReportWebService.DAO.WeatherDao;
import com.jsp.WeatherReportWebService.DTO.Weather;

@Service
public class WeatherService {
	
	@Autowired
	WeatherDao dao;
	
	//insert weather obj into db.
	public Weather insertWeather(Weather weather)
	{
		return dao.save(weather);
	}
	
	//To fetch all the datA TO display from db.
	public List<Weather> getAllWeather()
	{
		return dao.findAll();
	}
	
	//To search a obj is present or not...
	public Weather getWeatherById(int id)
	{
		Optional<Weather> opt=dao.findById(id);
		if(opt.isPresent())
		{
			return opt.get();
		}
		else
		{
			return null;
		}
	}
	
	//To delete a obj with the help if id..
	public String getDeleter(int id)
	{
		Weather w= getWeatherById(id);
		if(w!=null)
		{
			dao.delete(w);
			return "Deleted successfully";
		}
		else
		{
			return "Unsuccessfull";
		}
	}
	
	//To Update a value with the help of id...
	public String getUpdate(int id,String newCity)
	{
		Weather w= getWeatherById(id);
		if(w!=null)
		{
			w.setCity(newCity);
			dao.save(w);
			return "Updation successfully";
		}
		else
		{
			return "Unsuccessfully";
		}
	}
	
	//user defined for display list based on city...
	public List<Weather> getCityList(String city)
	{
		return dao.getCityNames(city);
	}
	
	//user defines upation for conditions..
	public String getupdateConditinsDb(String cond, String tempt)
	{
		int res= dao.getUpdateConditions(cond, tempt);
		if(res!=0)
		{
			return "update successfully";
		}
		else
		{
			return "unsuccessfully";
		}
	}

}
