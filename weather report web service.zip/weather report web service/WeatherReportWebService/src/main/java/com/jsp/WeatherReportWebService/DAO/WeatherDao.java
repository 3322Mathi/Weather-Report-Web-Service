package com.jsp.WeatherReportWebService.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.jsp.WeatherReportWebService.DTO.Weather;

import jakarta.transaction.Transactional;

public interface WeatherDao extends JpaRepository<Weather,Integer> {
		//All inherited methods are present which we can perform a DB operations.
	
		//To create user defined function for data base operation...
	@Query("select w from Weather w where w.city=?1")
	public List<Weather> getCityNames(String city);
	
	
	@Modifying
	@Transactional
	@Query("update Weather w set w.conditions=?1 where w.temperature=?2")
	public int getUpdateConditions(String cond, String tempt);
	

}
