package com.jsp.WeatherReportWebService.CONTROLLER;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.WeatherReportWebService.DTO.Weather;
import com.jsp.WeatherReportWebService.SERVICE.WeatherService;

@RestController
public class WeatherController {
	
	
	@Autowired
	WeatherService service;
	
	
	//insertWeatherReport
	@PostMapping("/weather")
	public Weather insertWeatherReport(@RequestBody Weather weather)
	{
		return service.insertWeather(weather);
	}
	
	//Display ALL
	@GetMapping("/weather")
	public List<Weather> getAllReports()
	{
		return service.getAllWeather();
	}
	
	//To search a obj 
	@GetMapping("/getid")
	public Weather getSearch(@RequestParam int id)
	{
		return service.getWeatherById(id);
	}
	
	//RestAPI for deletion
	@DeleteMapping("/getdelete")
	public String deleteId(@RequestParam int id)
	{
		return service.getDeleter(id);
		
	}
	//RestApi for updation process...
	@PutMapping("/weather")
	public String Updation(@RequestParam int id,String city)
	{
		return service.getUpdate(id,city);
	}
	
	//userDefined restapi for city display..
	@GetMapping("/cityName")
	public List<Weather> getCityNameList(@RequestParam String city)
	{
		return service.getCityList(city);
	}
	
	//userDefined restapi for condition update..
	@PutMapping("/condition")
	public String UpdateConditions(@RequestParam String cond, String temp)
	{
		return service.getupdateConditinsDb(cond,temp);
	}

}
